enum Type{ Temperature, Precipitation}
public class BinarySearch {

    public void searchEntry( ClimateRecord[] list ,Type attribute,Double magnitude, Integer month, Integer year, String region, boolean duplicate){ //using integer class so we can tell when nothing null supplied
        int low=0;
        int high=list.length-1;

        LinkedList finalList = new LinkedList();

        if(region!=null){
            whileLoop:
            while(low<=high){
                int mid = (low+high)/2;
                if(list[mid].getRegion().equalsIgnoreCase(region)){
                    //Region is definitely null in this case since it was checked in the earlier if condition
                    //so we don't check it's match below
                    boolean yearMatch = (year == null || list[mid].getYear() == year);
                    boolean magnitudeMatch = (magnitude == null || list[mid].getTemperature() == magnitude);
                    boolean monthMatch = (month == null || list[mid].getMonth() == month);

                    for(int i=mid;i< list.length; i++){
                        if(!list[i].getRegion().equalsIgnoreCase(region)) break;
                        if(yearMatch && magnitudeMatch && monthMatch){
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                        }
                    }
                    for(int i=mid-1;i>= 0; i--){
                        if(!list[i].getRegion().equalsIgnoreCase(region)) break;
                        if(yearMatch && magnitudeMatch && monthMatch){
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                        }
                    }
                    break;

                }
                else if(list[mid].getRegion().compareToIgnoreCase(region)<0){
                    low=mid+1;
                }
                else if(list[mid].getRegion().compareToIgnoreCase(region)>0){
                    high = mid-1;
                }
            }
        }
        else if(month!=null){
            whileLoop:
            while(low<=high){
                int mid = (low+high)/2;
                if(list[mid].getMonth()==month){
                    //Region is definitely null in this case since it was checked in the earlier if condition
                    //so we don't check it's match below
                    boolean yearMatch = (year == null || list[mid].getYear() == year);
                    boolean magnitudeMatch = (magnitude == null || list[mid].getTemperature() == magnitude);

                    for(int i=mid;i< list.length; i++){
                        if(list[i].getMonth()!=month) break;
                        if(yearMatch && magnitudeMatch){
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                        }
                    }
                    for(int i=mid-1;i>= 0; i--){
                        if(list[i].getMonth()!=month) break;
                        if(yearMatch && magnitudeMatch){
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                        }
                    }
                    break;

                }
                else if(list[mid].getMonth()<month){
                    low=mid+1;
                }
                else if(list[mid].getMonth()>month){
                    high = mid-1;
                }
            }
        }
        else if(year!=null){
            whileLoop:
            while(low<=high){
                int mid = (low+high)/2;
                if(list[mid].getYear()==year){
                    boolean magnitudeMatch = (magnitude == null || list[mid].getTemperature() == magnitude);


                    for(int i=mid;i< list.length; i++){
                        if(list[i].getYear()!=year) break;
                        if(magnitudeMatch){
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                        }
                    }
                    for(int i=mid-1;i>= 0; i--){
                        if(list[i].getYear()!=year) break;
                        if(magnitudeMatch){
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                        }
                    }

                    break;
                }
                else if(list[mid].getYear()<year){
                    low=mid+1;
                }
                else if(list[mid].getYear()>year){
                    high = mid-1;
                }
            }
        }
        else if(magnitude!=null){
            whileLoop:
            while(low<=high){
                int mid = (low+high)/2;
                if(list[mid].getTemperature()==magnitude){
                    for(int i=mid;i< list.length; i++){
                        if(list[i].getTemperature()!=magnitude) break;
                            finalList.addData(list[i]);
                            if(!duplicate){
                                break whileLoop;
                            }
                    }
                    for(int i=mid-1;i>= 0; i--){
                        if(list[i].getTemperature()!=magnitude) break;
                        finalList.addData(list[i]);
                        if(!duplicate){
                            break whileLoop;
                        }
                    }
                    break;
                }
                else if(list[mid].getTemperature()<magnitude){
                    low=mid+1;
                }
                else if(list[mid].getTemperature()>magnitude){
                    high = mid-1;
                }
            }

        }
        else{
            System.out.println("No parameter has been provided for search");
        }
        System.out.println("\nSearched data");
        finalList.display(); //showing the content now

    }
}
