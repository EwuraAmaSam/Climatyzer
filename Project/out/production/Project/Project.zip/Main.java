import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
/*        ClimateRecord[] dataPoints = {
                new ClimateRecord("Upper West",2015,9,25.4,2.5),
                new ClimateRecord("Savannah Region",2018,8,32,4.7),
                new ClimateRecord("Greater Accra",2011,4,21,2.5),
                new ClimateRecord("Greater Accra",2011,4,21,2.5),



        };



        System.out.println("Original array:");
        for (ClimateRecord dp : dataPoints) {
            System.out.println(dp);
        }

        // Sort by temperature
        DataSorting.mergeSort(dataPoints, "temperature");
        System.out.println("\nSorted by temperature:");
        for (ClimateRecord dp : dataPoints) {
            System.out.println(dp);
        }
        
          // Sort by year
         DataSorting.mergeSort(dataPoints, "year");
         System.out.println("\nSorted by year:");
         for (ClimateRecord dp : dataPoints) {
         System.out.println(dp);
         }
          
         // Sort by month
          DataSorting.mergeSort(dataPoints, "month");
          System.out.println("\nSorted by month:");
         for (ClimateRecord dp : dataPoints) {
         System.out.println(dp);
         }*/

        ClimateRecord[] load = new fileloader("Book1.csv").loadData();
        for(ClimateRecord rec: load){
            System.out.println(rec);
        }

        BinarySearch search = new BinarySearch();

         //search.searchEntry(dataPoints,Type.Temperature,21.0,4,2011,"Greater Accra",false);


         
    }
}
