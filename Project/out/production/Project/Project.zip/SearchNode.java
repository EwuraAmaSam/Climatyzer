public class SearchNode {
    ClimateRecord data;
    SearchNode next; // next node for singly linked list

    public SearchNode(ClimateRecord data){
        this.data= data;
    }
}
