import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class fileloader{
    private String filePath;

    public fileloader(String filePath) {
        this.filePath = filePath;
    }

    public ClimateRecord[] loadData() throws IOException {
        BufferedReader br = null;
        ClimateRecord[] records = new ClimateRecord[100];  // Initial array size, can be adjusted or resized dynamically
        int recordCount = 0;

        try {
            br = new BufferedReader(new FileReader(filePath));
            String line;

            // Read the first line to determine column types
            line = br.readLine();
            String[] headers = line.split(",");
            int regionIndex = -1;
            int yearIndex = -1;
            int monthIndex = -1;
            int tempIndex = -1;
            int precipIndex = -1;

            // Determine if the first line is a header or data
            boolean isHeader = false;
            for (String value : headers) {
                if (value.trim().toLowerCase().contains("region") || 
                    value.trim().toLowerCase().contains("year") || 
                    value.trim().toLowerCase().contains("month") || 
                    value.trim().toLowerCase().contains("temp") || 
                    value.trim().toLowerCase().contains("precip")) {
                    isHeader = true;
                    break;
                }
            }

            if (isHeader) {
                // Determine column indices based on header
                for (int i = 0; i < headers.length; i++) {
                    String header = headers[i].trim().toLowerCase();
                    if (header.contains("region")) {
                        regionIndex = i;
                    } else if (header.contains("year")) {
                        yearIndex = i;
                    } else if (header.contains("month")) {
                        monthIndex = i;
                    } else if (header.contains("temp") || header.contains("temperature")) {
                        tempIndex = i;
                    } else if (header.contains("precip") || header.contains("precipitation")) {
                        precipIndex = i;
                    }
                }
            } else {
                // If no header, assume standard order and process the first line as data
                regionIndex = 0;
                yearIndex = 1;
                monthIndex = 2;
                tempIndex = 3;
                precipIndex = 4;

                if (headers.length >= 5) {
                    processLine(records, headers, regionIndex, yearIndex, monthIndex, tempIndex, precipIndex, recordCount);
                    recordCount++;
                }
            }

            // Process the rest of the lines
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length == headers.length) {
                    if (recordCount >= records.length) {
                        records = resizeArray(records);  // Resize array if needed
                    }
                    processLine(records, values, regionIndex, yearIndex, monthIndex, tempIndex, precipIndex, recordCount);
                    recordCount++;
                } else {
                    System.err.println("Skipping malformed line: " + line);
                }
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }

        // Trim the array to the actual size of the records
        ClimateRecord[] trimmedRecords = new ClimateRecord[recordCount];
        System.arraycopy(records, 0, trimmedRecords, 0, recordCount);
        return trimmedRecords;
    }

    private void processLine(ClimateRecord[] records, String[] values, int regionIndex, int yearIndex, int monthIndex, int tempIndex, int precipIndex, int recordCount) {
        try {
            String region = regionIndex != -1 ? values[regionIndex].trim().replace("\"", "") : "";
            int year = yearIndex != -1 ? Integer.parseInt(values[yearIndex].trim().replace("\"", "")) : 0;
            int month = monthIndex != -1 ? Integer.parseInt(values[monthIndex].trim().replace("\"", "")) : 0;
            double temperature = tempIndex != -1 ? Double.parseDouble(values[tempIndex].trim().replace("\"", "")) : 0.0;
            double precipitation = precipIndex != -1 ? Double.parseDouble(values[precipIndex].trim().replace("\"", "")) : 0.0;

            records[recordCount] = new ClimateRecord(region, year, month, temperature, precipitation);
        } catch (NumberFormatException e) {
            System.err.println("Error parsing line: " + String.join(",", values) + " - " + e.getMessage());
        }
    }

    private ClimateRecord[] resizeArray(ClimateRecord[] original) {
        ClimateRecord[] newArray = new ClimateRecord[original.length * 2];
        System.arraycopy(original, 0, newArray, 0, original.length);
        return newArray;
    }

    public static void main(String[] args) {
        try {
            // Replace with the path to your CSV file
            fileloader loader = new fileloader("Book1.csv");
            ClimateRecord[] records = loader.loadData();

            for (ClimateRecord record : records) {
                System.out.println(record);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
